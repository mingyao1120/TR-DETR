import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.functional import multi_head_attention_forward as mha

class QueryGuidedVideoSummarization(nn.Module):
    def __init__(self, D, drop_rate=0.0):
        super(QueryGuidedVideoSummarization, self).__init__()
        # Define the parameters for attention score calculation
        self.w = nn.Parameter(torch.randn(D))
        self.W_m1 = nn.Linear(D, D)
        self.W_m2 = nn.Linear(D, D)
        self.b_m = nn.Parameter(torch.randn(D))
        # Define the projection matrix for query context
        self.W_Q = nn.Linear(D, D)
        # Define the parameters for graph convolution layer
        self.W_A1 = nn.Linear(2 * D, D)
        self.W_A2 = nn.Linear(D, D)
        self.W_A3 = nn.Linear(2 * D, D)

        # CQA
        self.dropout = nn.Dropout(p=drop_rate)
        w4C = torch.empty(D, 1)
        w4Q = torch.empty(D, 1)
        w4mlu = torch.empty(1, 1, D)
        nn.init.xavier_uniform_(w4C)
        nn.init.xavier_uniform_(w4Q)
        nn.init.xavier_uniform_(w4mlu)
        self.w4C = nn.Parameter(w4C, requires_grad=True)
        self.w4Q = nn.Parameter(w4Q, requires_grad=True)
        self.w4mlu = nn.Parameter(w4mlu, requires_grad=True)

    def forward(self, v, t, src_vid_mask, src_txt_mask):
        T, N = v.size(1), t.size(1)

        # Compute the attention score matrix M
        # M = torch.einsum("d,tbd,nbd->btn", self.w,
        #                  torch.tanh(self.W_m1(v) + self.W_m2(t).unsqueeze(1) + self.b_m),
        #                  torch.ones((T, N)))
        # M = mha.scaled_dot_product_attention(self.w.unsqueeze(0), self.W_m1(v), self.W_m2(t), attn_mask=~(src_vid_mask.unsqueeze(-1) & src_txt_mask.unsqueeze(1)))[0]
        M = self.trilinear_attention(v, t)
        # Apply the masks to avoid attention to padding tokens
        # print(M.shape) torch.Size([32, 75, 25]) ,注意下面的代码！
        M = M.masked_fill(src_vid_mask.unsqueeze(-1) == 0, -1e9)
        M = M.masked_fill(src_txt_mask.unsqueeze(1) == 0, -1e9)
        
        # Compute the query-guided frame features V^b
        V_b = torch.cat([v.permute(1, 0, 2), torch.einsum("btn,nbd->tbd", torch.softmax(M, dim=-1), self.W_Q(t).permute(1, 0, 2))], dim=-1)
        # Compute the adjacency matrix A
        # B = torch.einsum("tbd,nbd->btn", V_b @ self.W_A1, t @ self.W_A2)
        # print(V_b.shape, t.shape)
        B = torch.einsum("tbd,nbd->btn", self.W_A1(V_b), self.W_A2(t).permute(1, 0, 2))
        A = torch.softmax(B, dim=-1) @ torch.softmax(B.transpose(1, 2), dim=-1)
        # Add self-loops to the adjacency matrix
        A = A.cuda() + torch.eye(T).unsqueeze(0).cuda()
        # Compute the enhanced features V^e
        # print(A.shape, V_b.shape)
        V_e = A @  self.W_A3(V_b).permute(1, 0, 2) # (b, t ,d)
        # Return the output features
        return V_e.cuda()
    
    # CQA中的注意力分数
    def trilinear_attention(self, context, query):
        batch_size, c_seq_len, dim = context.shape
        batch_size, q_seq_len, dim = query.shape
        context = self.dropout(context)
        query = self.dropout(query)
        subres0 = torch.matmul(context, self.w4C).expand([-1, -1, q_seq_len])  # (batch_size, c_seq_len, q_seq_len)
        subres1 = torch.matmul(query, self.w4Q).transpose(1, 2).expand([-1, c_seq_len, -1])
        subres2 = torch.matmul(context * self.w4mlu, query.transpose(1, 2))
        res = subres0 + subres1 + subres2  # (batch_size, c_seq_len, q_seq_len)
        return res

# from qd_detr.start_end_dataset import StartEndDataset,start_end_collate, prepare_batch_inputs
# # 先单独测试一下clip特征，读取对应的QV训练集
# dset_name = 'hl'
# data_path = 'data/highlight_train_release.jsonl'
# v_feat_dirs = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_features'
# q_feat_dir = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_text_features'
# train_set = StartEndDataset(dset_name, data_path, v_feat_dirs, q_feat_dir)

# # print(train_set[0]['model_inputs']['pos_idx'])

# from torch.utils.data import DataLoader
# train_loader = DataLoader(
#     train_set,
#     collate_fn=start_end_collate,
#     batch_size=32,
#     num_workers=4,
#     shuffle=True,
#     pin_memory=True
# )
# # next(iter(train_loader)得到的是一个元组，分别为model_input和target
# batch = next(iter(train_loader))
# model_inputs, targets = prepare_batch_inputs(batch[1], 'cpu', non_blocking=False)

# video_output, text_output, pos_idx, neg_idx = model_inputs['src_vid'], model_inputs['src_txt'], model_inputs['src_pos_idx'], model_inputs['src_neg_idx']
# src_txt_mask,   src_vid_mask = model_inputs['src_txt_mask'], model_inputs['src_vid_mask']


# QCE = QueryGuidedVideoSummarization(512)
# print(QCE(video_output,text_output, src_vid_mask, src_txt_mask ))
    
