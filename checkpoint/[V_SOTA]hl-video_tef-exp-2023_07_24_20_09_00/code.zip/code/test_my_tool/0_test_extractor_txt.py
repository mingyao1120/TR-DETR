
import torch
import numpy as np
from os.path import join, exists
import clip
from numpy import save, load
import json

from run_on_video.data_utils import ClipFeatureExtractor
data_ratio = 1.0
data_path = 'data/highlight_train_release.jsonl'
desti_path = '/home/4TDisk/zmy/datasets/01_Charades-STA/UMT_feature_VGG/charades/clip_text_features/'

def load_jsonl(filename):
    with open(filename, "r") as f:
        return [json.loads(l.strip("\n")) for l in f.readlines()]

# Json文件中的一行
def load_data():
    datalist = load_jsonl(data_path)
    if data_ratio != 1:
        n_examples = int(len(datalist) * data_ratio)
        datalist = datalist[:n_examples]
        # logger.info("Using {}% of the data: {} examples"
        #             .format(data_ratio * 100, n_examples))
    return datalist

# 字典Json
data = load_data()
feature_extractor = ClipFeatureExtractor()

# # Json文件中的一行

# for meta in data:
    
#     qid = meta['qid']

#     # if qid == 1:
#     #         break

#     sequence = meta['query']
#     feats = feature_extractor.encode_text(sequence)
#     # 这里直接取出第一维度，代替了squeeze
#     feats = torch.tensor([item.cpu().detach().numpy() for item in feats][0])
#     # feats = feats.squeeze(0)
#     # 先分割
#     # text = clip.tokenize(sequence).to(device)
#     # print(text)
#     # tokens = feature_extractor.encode_token(text)
#     # text_feats = feature_extractor.encode_text(text)
#     # feats = np.array([item.cpu().detach().numpy() for item in feats], dtype=np.float32)
#     print(sequence)
#     print(feats.shape)
#     # "{}.npz".format(qid)
#     # print('qid{}.npz'.format(qid))
#     np.savez(desti_path+'qid{}.npz'.format(qid),token = feats)

# print('测试~')
# sequence = 'A man is cutting an apple.'
# feats = feature_extractor.encode_text(sequence)

# q_feat = np.load(join(desti_path, "qid{}.npz".format(0))) # 'token', 'text'
# v_feat = np.load('/home/4TDisk/zmy/datasets/01_Charades-STA/UMT_feature_VGG/charades/rgb_features/0FVYR.npy') # 'token', 'text'
# (190, 4096) ,(252, 4096) = 42s ,(222, 4096) = 38s,1s有6帧
# print(feat.shape)

# 从数据集中读取出来的文本特征
device = 'cuda:0'
meta = data[0]
qid = meta['qid']
q_feat = np.load('/home/4TDisk/zmy/datasets/MomentDETR_features/clip_text_features/qid{}.npz'.format(qid))["last_hidden_state"] # 'token', 'text'


query = meta['query']
word = 'Few official patriots bring us through their safety camps and procedures.'
query_copy = query
# torch.Size([12, 512]) torch.Size([6, 512])
q_feat1 = feature_extractor.encode_text(query)[0]
q_feat2 = feature_extractor.encode_text(query)[1]
# 加上起止标签，然后分割
# text = clip.tokenize(query).to(device)
w_feat1 = feature_extractor.encode_text(word)[0]
query_copy_feat1 = feature_extractor.encode_text(query_copy)[0]

# print(query, q_feat1.shape,  q_feat2.shape)
print(query,  q_feat1[3] - w_feat1[3], q_feat1[3] - query_copy_feat1[3])
