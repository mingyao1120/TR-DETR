import torch
import numpy as np
from os.path import join, exists
import clip
from numpy import save, load
import json
import nltk
from torch.nn.utils import rnn
pos_tags_dict = {
    "NNS": 0,
    "NNP": 0,
    "NN": 0,
    "VB": 1,
    "VBD": 1,
    "VBN": 1,
    "VBP": 1,
    "VBG": 1,
    "VBZ": 1,
    "MD": 1,
    "IN": 2,
    "JJ": 0,
    "PRP": 0,
    "JJR": 7,
    "JJS": 7,
    "RB": 1,
    "RBR": 1,
    "RBS": 1,
    "LS": 7,
    "RP": 0,
    "SYM": 7,
    "TO": 5,
    "PRP$": 0,
    "WDT": 5,
    "WP": 3,
    "WP$": 3,
    "WRB": 1,
}
data_ratio = 1.0
data_path = '/home/4TDisk/zmy/repository/BackBone/QD-DETR_0411/data/highlight_train_release.jsonl'

def load_jsonl(filename):
    with open(filename, "r") as f:
        return [json.loads(l.strip("\n")) for l in f.readlines()]

# Json文件中的一行
def load_data():
    datalist = load_jsonl(data_path)
    if data_ratio != 1:
        n_examples = int(len(datalist) * data_ratio)
        datalist = datalist[:n_examples]
        # logger.info("Using {}% of the data: {} examples"
        #             .format(data_ratio * 100, n_examples))
    return datalist
# Json文件中的每行
data = load_data()
meta = data[0]


qid = meta['qid']
vid = meta['vid']
text_feats = np.load('/home/4TDisk/zmy/datasets/MomentDETR_features/clip_text_features/qid{}.npz'.format(qid))["last_hidden_state"]
vid_features = np.load('/home/4TDisk/zmy/datasets/MomentDETR_features/clip_features/{}.npz'.format(vid))["features"]

text = meta['query']
words = nltk.word_tokenize(text)
words_tags = nltk.pos_tag(words)
pos_tags = []
# print(sentence)
for word, tag in words_tags:
    if tag in pos_tags_dict.keys():
        pos_tags.append(pos_tags_dict[tag] + 1)
    else:
        # 使用连词代替
        pos_tags.append(22)
        # print(word, self.pos_tags[tag] + 1)
clip_text_length = len(text_feats)

# 这里要进行升维，否则无法广播
pos_tags = torch.tensor(pos_tags, dtype=torch.long).unsqueeze(0)

# 进行处理，得到实体相关和动作相关的分量
# src_txt_tags  = rnn.pad_sequence(pos_tags)
# if src_txt_tags.shape != pos_tags.shape:
#     src_txt_tags = src_txt_tags[:, :text_feats.shape[1]]
# TODO 是否用得上标签都要试试！
src_txt_tags  = rnn.pad_sequence(pos_tags, batch_first=True)
#  2023.04.12：解决预训练的维度不一致问题！
# print('################'+str(src_txt_tags.shape))
# print('################'+str(src_txt.shape))

zeros = src_txt_tags.new_zeros(src_txt_tags.shape)
ones = src_txt_tags.new_ones(src_txt_tags.shape)
entity_prob = torch.where(
    # 这里改一下，直接完全滤除其他(1,0,1)->(1,0,)
    torch.abs(src_txt_tags - 2) < 1e-10, zeros, ones)
action_prob = torch.where(
    torch.abs(src_txt_tags - 1) < 1e-10, zeros, ones)

print(entity_prob.squeeze(1))
print(src_txt_tags)
# ALL
# text_feats_nose = text_feats[1:-1]
# print(text_feats_nose.shape)
# print(vid_features.shape)
# sim_mar = vid_features@text_feats_nose.T
# sim_vec = sim_mar.sum(-1)
# average = sim_vec.mean()
# num_pos = np.array(np.where(sim_vec >= average)).squeeze(0)
# num_neg = np.array(np.where(sim_vec < average)).squeeze(0)
# (46,)
# (29,)
# [ 1  2  3  7  9 12 18 24 25 26 28 29 30 31 32 34 38 39 40 41 42 43 44 45
#  46 47 48 52 53 54 55 56 57 58 59 61 64 65 66 67 68 69 70 71 72 74]
# [ 0  4  5  6  8 10 11 13 14 15 16 17 19 20 21 22 23 27 33 35 36 37 49 50
#  51 60 62 63 73]
# print(num_pos.shape)
# print(num_neg.shape)
# print(num_pos)
# print(num_neg)


# TODO Entity
# text_feats_nose = text_feats[1:-1]
# text_feats_nose = text_feats_nose*entity_prob.T
# # print(text_feats_nose.shape)
# # print(vid_features.shape)
# sim_mar = vid_features@text_feats_nose.T
# sim_vec = sim_mar.sum(-1)
# average = sim_vec.mean()
# num_pos = np.array(np.where(sim_vec >= average)).squeeze(0)
# num_neg = np.array(np.where(sim_vec < average)).squeeze(0)
# print(num_pos.shape)
# print(num_neg.shape)
# print(num_pos)
# print(num_neg)


# some military patriots takes us through their safety procedures and measures.
# tensor([22, 22,  1,  1,  2,  1,  3,  1,  1,  1, 22,  1, 22, 22])
# tensor([1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1])
# tensor([1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1])
# print(text)
# print(pos_tags)
# print(entity_prob)
# print(action_prob)