import torch
import torch.nn as nn

# from .operation import Conv1D

import torch.nn.functional as F
import numpy as np
import math

def mask_logits(inputs, mask, mask_value=-1e30):
    mask = mask.type(torch.float32)
    return inputs + (1.0 - mask) * mask_value

import torch.utils.data
from torch.nn import functional as F

import math
import torch
from torch.nn.parameter import Parameter
from torch.nn.functional import pad
from torch.nn.modules import Module
from torch.nn.modules.utils import _single, _single, _triple

class Conv1D(nn.Module):
    def __init__(self,
                 in_dim,
                 out_dim,
                 kernel_size,
                 stride=1,
                 padding=0,
                 dilation=1,
                 groups=1,
                 bias=True):
        super(Conv1D, self).__init__()

        self.conv = nn.Conv1d(in_dim,
                              out_dim,
                              kernel_size=kernel_size,
                              stride=stride,
                              padding=padding,
                              dilation=dilation,
                              groups=groups,
                              bias=bias)

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        return x

class MultiStepConvEncoder(nn.Module):
    def __init__(self,
                 in_dim,
                 out_dim,
                 num_layers,
                 num_step=1,
                 bi_direction=False,
                 drop_rate=0.0):
        super(MultiStepConvEncoder, self).__init__()

        self.num_step = num_step
        self.out_dim = out_dim
        self.layers_norm = nn.LayerNorm(in_dim, eps=1e-6)

        self.dropout = nn.Dropout(p=drop_rate)
        # 这里将LSTM改为Conv1D
        self.encoder = nn.ModuleList([
            Conv1D(in_dim=in_dim if i == 0 else out_dim // 2 if bi_direction else out_dim,
                   out_dim=out_dim // 2 if bi_direction else out_dim,
                   kernel_size=i + 1,
                   padding=0) for i in range(num_step)
        ])

        self.linear = Conv1D(in_dim=int(num_step * out_dim),
                             out_dim=out_dim,
                             kernel_size=1,
                             stride=1,
                             bias=True,
                             padding=0)

    def forward(self, input_feature):
        input_feature = self.layers_norm(input_feature)
        B, seq_len, _ = input_feature.shape
        # assert seq_len // self.num_step == 0, "length of sequence({}) must be devided by num_step({})".format(
        # seq_len, self.num_step)
        output = []
        for i in range(self.num_step):
            encoder_i = self.encoder[i]
            output_i = input_feature.new_zeros([B, seq_len, self.out_dim])
            input_i_len = (seq_len // (i + 1)) * (i + 1)
            for j in range(i + 1):
                input_j = input_feature[:, j:input_i_len:(i + 1), :]
                output_j = encoder_i(input_j)
                # print(output_j.shape, input_j.shape) # 卷积之后尺度发生了变化，这里需要填充一下
                if (input_j.size(1) - output_j.size(1)) != 0: # 判别一下是否是卷积引起的维度变换
                    pad_zero = torch.zeros([B, input_j.size(1) - output_j.size(1), self.out_dim]).cuda() # 但愿这样不会影响后续的值
                    output_j = torch.cat([output_j, pad_zero], dim=1) 
                    # print(output_j.shape)
                output_i[:, j:input_i_len:(i + 1), :] = output_j
            output_i = self.dropout(output_i)
            output.append(output_i)
        output = torch.cat(output, dim=2)
        output = self.linear(output)
        return output



class MultiConvAttention(nn.Module):
    # def __init__(self, configs):
    def __init__(self, dim, num_heads, drop_rate, num_layers, num_step, bi_direction):
        super(MultiConvAttention, self).__init__()
        dim = dim
        num_heads = num_heads
        drop_rate = drop_rate
        num_layers = num_layers
        num_step = num_step
        bi_direction = bi_direction

        assert dim % num_heads == 0, 'The channels (%d) is not a multiple of attention heads (%d)' % (
            dim, num_heads)
        self.head_size, self.num_heads, self.dim = int(
            dim / num_heads), num_heads, dim
        self.dropout = nn.Dropout(p=drop_rate)
        self.query = MultiStepConvEncoder(in_dim=dim,
                                          out_dim=dim,
                                          num_layers=num_layers,
                                          num_step=num_step,
                                          bi_direction=bi_direction,
                                          drop_rate=drop_rate)
        self.key = MultiStepConvEncoder(in_dim=dim,
                                        out_dim=dim,
                                        num_layers=num_layers,
                                        num_step=num_step,
                                        bi_direction=bi_direction,
                                        drop_rate=drop_rate)
        self.value = MultiStepConvEncoder(in_dim=dim,
                                          out_dim=dim,
                                          num_layers=num_layers,
                                          num_step=num_step,
                                          bi_direction=bi_direction,
                                          drop_rate=drop_rate)
        # 暂时换为线性层看看，记得注释掉模型中的其他架构
        # self.query = F.linear(in_dim=dim,out_dim=dim, num_layers=num_layers,drop_rate=drop_rate)
        # self.key = F.linear(in_dim=dim,out_dim=dim, num_layers=num_layers,drop_rate=drop_rate)
        # self.value = F.linear(in_dim=dim,out_dim=dim, num_layers=num_layers,drop_rate=drop_rate)

      
        self.layer_norm1 = nn.LayerNorm(dim, eps=1e-6)
        self.layer_norm2 = nn.LayerNorm(dim, eps=1e-6)
        self.out_layer1 = Conv1D(in_dim=dim,
                                 out_dim=dim,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0,
                                 bias=True)
        self.output_activation = nn.GELU()
        self.out_layer2 = Conv1D(in_dim=dim,
                                 out_dim=dim,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0,
                                 bias=True)

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_heads, self.head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1,
                         3)  

    @staticmethod
    def combine_last_two_dim(x):
        old_shape = list(x.size())
        new_shape = old_shape[:-2] + [old_shape[-2] * old_shape[-1]]
        return x.reshape(shape=new_shape)
    
    def forward(self, x, mask=None):
        output = self.layer_norm1(x)  
        query = self.transpose_for_scores(
            self.query(output)) 
        key = self.transpose_for_scores(self.key(output))
        value = self.transpose_for_scores(self.value(output))
        attention_scores = torch.matmul(query, key.transpose(
            -1, -2))  
        attention_scores = attention_scores / math.sqrt(self.head_size)
        if mask is not None:  
            mask = mask.unsqueeze(1).unsqueeze(
                2) 
            attention_scores = mask_logits(attention_scores, mask)
        attention_probs = torch.softmax(
            attention_scores,
            dim=-1) 
        attention_probs = self.dropout(attention_probs)
        value = torch.matmul(
            attention_probs,
            value) 
        value = self.combine_last_two_dim(value.permute(
            0, 2, 1, 3))  
        output = self.dropout(value)
        residual = x + output
        output = self.layer_norm2(residual)
        output = self.out_layer1(output)
        output = self.output_activation(output)
        output = self.dropout(output)
        output = self.out_layer2(output) + residual
        return output