# Copyright 2023 Google LLC.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import jax.numpy as jnp
import torch.nn as nn

class MlpBlock(torch.nn.Module):
  def __init__(self, mlp_dim, out_dim):
    super().__init__()
    self.linear1 = torch.nn.Linear(out_dim, mlp_dim)
    self.linear2 = torch.nn.Linear(mlp_dim, out_dim)

  def forward(self, x):
    # print(x.shape) # torch.Size([32, 256, 75])
    y = self.linear1(x)
    y = torch.nn.functional.gelu(y)
    return self.linear2(y)


class MixerBlock(torch.nn.Module):
  """Mixer block layer."""
  def __init__(self, tokens_mlp_dim, channels_mlp_dim, hidden_dim):
    super().__init__()
    self.layer_norm1 = torch.nn.LayerNorm(hidden_dim)
    self.layer_norm2 = torch.nn.LayerNorm(hidden_dim)
    self.token_mixing = MlpBlock(tokens_mlp_dim, hidden_dim)
    self.channel_mixing = MlpBlock(channels_mlp_dim, hidden_dim)

  def forward(self, x):
    y = self.layer_norm1(x)
    y = y
    y = self.token_mixing(y)
    y = y
    x = x + y
    y = self.layer_norm2(x)
    return x + self.channel_mixing(y)


class MlpMixer(nn.Module):
  """Mixer architecture."""
  def __init__(self, num_classes = None, num_blocks = 1,
               hidden_dim = 256, tokens_mlp_dim = 256, channels_mlp_dim = 2048):
    super().__init__()
    self.linear = torch.nn.Linear(hidden_dim, hidden_dim)
    self.mixer_blocks = torch.nn.ModuleList([
        MixerBlock(tokens_mlp_dim, channels_mlp_dim, hidden_dim)
        for _ in range(num_blocks)])
    self.pre_head_layer_norm = torch.nn.LayerNorm(hidden_dim)
    if num_classes:
      self.head = torch.nn.Linear(hidden_dim, num_classes)

  def forward(self, inputs):
    x = self.linear(inputs) # bs seq_len hidden_dim
    for mixer_block in self.mixer_blocks:
      x = mixer_block(x)
    x = self.pre_head_layer_norm(x)
    # x = x.mean(dim=1) # bs hidden_dim，保留seq_len
    if hasattr(self, 'head'):
      x = self.head(x)
    return x


  
# x = torch.ones((32, 75, 256))
# mlp = MlpMixer()
# print(mlp(x).shape)

