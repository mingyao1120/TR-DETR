import torch
import torch.nn as nn
import torch.nn.functional as F

# Define the WTI class
class WTI(nn.Module):
    def __init__(self, D):
        super(WTI, self).__init__()
        # Define the text and visual embedding functions as submodules
        self.f_t = nn.Linear(D, D)
        self.f_v = nn.Linear(D, D)
        # Define the text and visual weight functions as submodules
        self.f_tw = nn.Sequential(
            nn.Linear(D, D),
            nn.ReLU(),
            nn.Linear(D, 1),
            nn.Softmax(dim=1)
        )
        self.f_tv = nn.Sequential(
            nn.Linear(D, D),
            nn.ReLU(),
            nn.Linear(D, 1),
            nn.Softmax(dim=1)
        )
        # Define the temperature parameter as a buffer
        self.register_buffer("tau", torch.tensor(0.1))

    def forward(self, t, v):
        # Get the batch size and the feature dimension
        B, N_t, D = t.shape
        _, N_v, _ = v.shape
        # Compute the embeddings using f_t and f_v
        e_t = self.f_t(t) # shape: (B, N_t, D)
        e_v = self.f_v(v) # shape: (B, N_v, D)
        # Generate the fusion weights using f_tw and f_tv
        text_weight = self.f_tw(e_t) # shape: (B, N_t, 1)
        video_weight = self.f_tv(e_v) # shape: (B, N_v, 1)
        # Normalize the embeddings along the feature dimension
        e_t = e_t / e_t.norm(dim=-1, keepdim=True) # shape: (B, N_t, D)
        e_v = e_v / e_v.norm(dim=-1, keepdim=True) # shape: (B, N_v, D)
        # Compute the token interaction using einsum
        logits = torch.einsum("atc,bvc->abtv", [e_t, e_v])  # shape: (B, B, N_t, N_v)
        # Compute the t2v and v2t logits using max-pooling and weighted sum
        t2v_logits = logits.max(dim=-1)[0]  # shape: (B, B, N_t)
        t2v_logits = torch.einsum("abt,bt->ab", [t2v_logits, text_weight.squeeze()]) # shape: (B, B)
        v2t_logits = logits.max(dim=-2)[0]  # shape: (B, B, N_v)
        v2t_logits = torch.einsum("abv,bv->ab", [v2t_logits, video_weight.squeeze()]) # shape: (B, B)
        # Compute the retrieval logits using average
        retrieval_logits = (t2v_logits + v2t_logits) / 2.0  # shape: (B, B)
        return retrieval_logits

# Define the loss class
class WTINCELoss(nn.Module):
    def __init__(self, D):
        super(WTINCELoss, self).__init__()
        # Define the WTI submodule
        self.wti = WTI(D)

    def forward(self, t, v):
        # Get the batch size
        B = t.shape[0]
        # Compute the retrieval logits using WTI
        retrieval_logits = self.wti(t,v) # shape: (B,B)
        # Compute the numerator and denominator for v2t and t2v losses
        numerator_v2t = torch.exp(retrieval_logits.diag() / self.wti.tau) # shape: (B,)
        denominator_v2t = torch.exp(retrieval_logits / self.wti.tau).sum(dim=1) # shape: (B,)
        numerator_t2v = torch.exp(retrieval_logits.diag() / self.wti.tau) # shape: (B,)
        denominator_t2v = torch.exp(retrieval_logits / self.wti.tau).sum(dim=0) # shape: (B,)
        # Compute the v2t and t2v losses using log and mean
        loss_v2t = -torch.log(numerator_v2t / denominator_v2t).mean()
        loss_t2v = -torch.log(numerator_t2v / denominator_t2v).mean()
        # Return the sum of v2t and t2v losses
        return loss_v2t + loss_t2v
    
# loss = Loss(512)
# v = torch.ones((32, 75, 512))
# t = torch.ones((32, 32, 512))
# print(loss(t,v))