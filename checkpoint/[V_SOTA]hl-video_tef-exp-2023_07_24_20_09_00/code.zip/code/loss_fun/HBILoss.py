# Import Pytorch modules
import torch
import torch.nn as nn
import torch.nn.functional as F

# Define the module class for cross-modal representation learning
class CrossModal(nn.Module):
    def __init__(self, hidden_dim = 512, num_entities = 2, num_actions = 1, num_events = 1):
        super(CrossModal, self).__init__()
        # Entity classifier: a linear layer followed by a softmax activation
        self.entity_classifier = nn.Sequential(
            nn.Linear(hidden_dim, num_entities),
            nn.Softmax(dim=1)
        )
        # Action classifier: a linear layer followed by a softmax activation
        self.action_classifier = nn.Sequential(
            nn.Linear(hidden_dim, num_actions),
            nn.Softmax(dim=1)
        )
        # Event classifier: a linear layer followed by a softmax activation
        self.event_classifier = nn.Sequential(
            nn.Linear(hidden_dim, num_events),
            nn.Softmax(dim=1)
        )
        self.num_entities = num_entities
        self.num_actions =  num_actions
        self.num_events = num_events

    def forward(self, video_feature, text_feature, src_vid_mask, src_txt_mask):
        nums_clip, nums_word = video_feature.size(1), text_feature.size(1)

        # Apply the masks to the features
        video_feature = video_feature * src_vid_mask.unsqueeze(-1) # shape: (batch_size, nums_clip, hidden_dim)
        text_feature = text_feature * src_txt_mask.unsqueeze(-1) # shape: (batch_size, nums_word, hidden_dim)

        # Compute the entity-level similarity
        video_entity = self.entity_classifier(video_feature) # shape: (batch_size, nums_clip, num_entities)
        text_entity = self.entity_classifier(text_feature) # shape: (batch_size, nums_word, num_entities)
        
        video_entity = video_entity.view(-1, nums_clip, self.num_entities) # shape: (batch_size, nums_clip, num_entities)

        text_entity = text_entity.view(-1, nums_word, self.num_entities) # shape: (batch_size, nums_word, num_entities)

        entity_similarity = torch.matmul(video_entity, text_entity.transpose(1, 2)) # shape: (batch_size, nums_clip, nums_word)
        # Compute the action-level similarity
        video_action = self.action_classifier(video_feature) # shape: (batch_size, nums_clip, num_actions)
        text_action = self.action_classifier(text_feature) # shape: (batch_size, nums_word, num_actions)

        # Reshape the features to match the similarity matrix shape
        video_action = video_action.view(-1, nums_clip , self.num_actions) # shape: (batch_size, nums_clip * num_actions)
        text_action = text_action.view(-1, nums_word , self.num_actions) # shape: (batch_size, nums_word * num_actions)

        action_similarity = torch.matmul(video_action, text_action.transpose(1, 2)) # shape: (batch_size * nums_clip * num_actions,
                                                                        #        batch_size * nums_word * num_actions)

        # Compute the event-level similarity
        video_event = self.event_classifier(video_feature) # shape: (batch_size, nums_clip, num_events)
        text_event = self.event_classifier(text_feature) # shape: (batch_size, nums_word, num_events)

        # Reshape the features to match the similarity matrix shape
        video_event = video_event.view(-1, nums_clip , self.num_events) # shape: (batch_size, nums_clip * num_events)
        text_event = text_event.view(-1, nums_word , self.num_events) # shape: (batch_size, nums_word * num_events)

        event_similarity = torch.matmul(video_event, text_event.transpose(1, 2)) # shape: (batch_size * nums_clip * num_events,
                                                                    #        batch_size * nums_word * num_events)
        # Return the similarity matrices
        return entity_similarity, action_similarity, event_similarity


# Define the loss function class for cross-modal representation learning
class CrossModalLoss(nn.Module):
    def __init__(self, alpha = 1.0, beta = 2.0):
        super(CrossModalLoss, self).__init__()
        # Trade-off hyper-parameters
        self.alpha = alpha
        self.beta = beta

    def forward(self, entity_similarity, action_similarity, event_similarity):
        # Compute the contrastive loss at each semantic level
        entity_contrastive_loss = F.cross_entropy(entity_similarity.diag(), torch.arange(entity_similarity.size(0)))
        action_contrastive_loss = F.cross_entropy(action_similarity.diag(), torch.arange(action_similarity.size(0)))
        event_contrastive_loss = F.cross_entropy(event_similarity.diag(), torch.arange(event_similarity.size(0)))
        
        # Compute the Banzhaf Interaction loss at each semantic level
        entity_interaction_loss = torch.mean(torch.abs(entity_similarity - (action_similarity + event_similarity) / 2))
        action_interaction_loss = torch.mean(torch.abs(action_similarity - (entity_similarity + event_similarity) / 2))
        event_interaction_loss = torch.mean(torch.abs(event_similarity - (entity_similarity + action_similarity) / 2))

        # Compute the semantic alignment loss at each semantic level
        entity_alignment_loss = entity_contrastive_loss + self.alpha * entity_interaction_loss
        action_alignment_loss = action_contrastive_loss + self.alpha * action_interaction_loss
        event_alignment_loss = event_contrastive_loss + self.alpha * event_interaction_loss

        # Compute the KL divergence from entity-level similarity to action-level similarity
        entity_to_action_kl_loss = F.kl_div(F.softmax(action_similarity / 0.07), F.softmax(entity_similarity / 0.07), reduction='batchmean')
        # Compute the KL divergence from entity-level similarity to event-level similarity
        entity_to_event_kl_loss = F.kl_div(F.softmax(event_similarity / 0.07), F.softmax(entity_similarity / 0.07), reduction='batchmean')

        # Compute the total loss as the combination of semantic alignment losses and self-distillation losses
        total_loss = entity_alignment_loss + action_alignment_loss + event_alignment_loss + \
                    self.beta * (entity_to_action_kl_loss + entity_to_event_kl_loss)
        # Return the total loss
        return total_loss

from qd_detr.start_end_dataset import StartEndDataset,start_end_collate, prepare_batch_inputs
# 先单独测试一下clip特征，读取对应的QV训练集
dset_name = 'hl'
data_path = 'data/highlight_train_release.jsonl'
v_feat_dirs = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_features'
q_feat_dir = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_text_features'
train_set = StartEndDataset(dset_name, data_path, v_feat_dirs, q_feat_dir)

# print(train_set[0]['model_inputs']['pos_idx'])

from torch.utils.data import DataLoader
train_loader = DataLoader(
    train_set,
    collate_fn=start_end_collate,
    batch_size=32,
    num_workers=4,
    shuffle=True,
    pin_memory=True
)
# next(iter(train_loader)得到的是一个元组，分别为model_input和target
batch = next(iter(train_loader))
model_inputs, targets = prepare_batch_inputs(batch[1], 'cpu', non_blocking=True)

video_output, text_output, pos_idx, neg_idx = model_inputs['src_vid'], model_inputs['src_txt'], model_inputs['src_pos_idx'], model_inputs['src_neg_idx']
src_txt_mask,   src_vid_mask = model_inputs['src_txt_mask'], model_inputs['src_vid_mask']

model = CrossModal()
# print(video_output.shape, text_output.shape, src_vid_mask.shape, src_txt_mask.shape)
entity_similarity, action_similarity, event_similarity = model(video_output, text_output, src_vid_mask, src_txt_mask)
print(entity_similarity.shape, action_similarity.shape, event_similarity.shape)
loss = CrossModalLoss()
print(loss(entity_similarity, action_similarity, event_similarity))


    
