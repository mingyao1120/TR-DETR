import nltk
import torch
# 用这个初始化list，否则不能使用shape
import numpy as np
# 用于填充
from torch.nn.utils import rnn
# 自己定义的表
    # CC  并列连词  0        NNS 名词复数  1      UH 感叹词 2
    # CD  基数词  3           NNP 专有名词  1     VB 动词原型 4
    # DT  限定符  5          NNP 专有名词复数 1   VBD 动词过去式 4
    # EX  存在词  6          PDT 前置限定词  5    VBG 动名词或现在分词 4
    # FW  外来词   7         POS 所有格结尾  8    VBN 动词过去分词 4
    # IN  介词或从属连词 9    PRP 人称代词   10     VBP 非第三人称单数的现在时 4
    # JJ  形容词     11       PRP$ 所有格代词 17    VBZ 第三人称单数的现在时 4
    # JJR 比较级的形容词 11    RB  副词     12       WDT 以wh开头的限定词 18
    # JJS 最高级的形容词  11  RBR 副词比较级  12    WP 以wh开头的代词 19
    # LS  列表项标记   13      RBS 副词最高级  12    WP$ 以wh开头的所有格代词 20
    # MD  情态动词     4      RP  小品词  14        WRB 以wh开头的副词 21
    # NN  名词单数    1       SYM 符号     15       TO  to 16
    # ',': 22, '.': 23,

    # 三个数据集的词性占比，charades, activitynet, TACoS
    # 1:  38.6, 25.8, 27.8 || 4:  20,   18,  16  || 5:  22,  16,  20  || 9:  11.4, 15,6, 11
    # 10: 2,    3.5,  5.7  || 12: 0.6,  2.8, 1.5 || 14: 2.1, 1.1, 3.3 || 16: 0.9,  2,    1.1
    # 17: 1.3,  1.3,  0.35 || 22: 0.03, 1  , 1,2 || 23: 0,   7.1, 8.3
    
    # 自定义词义标签，构建词性字典
pos_tags = {
    "NNS": 0,
    "NNP": 0,
    "NN": 0,
    "VB": 1,
    "VBD": 1,
    "VBN": 1,
    "VBP": 1,
    "VBG": 1,
    "VBZ": 1,
    "MD": 1,
    "IN": 2,
    "JJ": 0,
    "PRP": 0,
    "JJR": 7,
    "JJS": 7,
    "RB": 1,
    "RBR": 1,
    "RBS": 1,
    "LS": 7,
    "RP": 0,
    "SYM": 7,
    "TO": 5,
    "PRP$": 0,
    "WDT": 5,
    "WP": 3,
    "WP$": 3,
    "WRB": 1,
}

text = 'Man in white top cuts up a watermelon.'
words = nltk.word_tokenize(text)
words_tags = nltk.pos_tag(words)
print(words_tags)
# sentences = [
#     'There is a man and a kid cutting an apple.',
#     'some military patriots takes us through their safety procedures and measures.',
#     'A mom and jer son eat as they watch TV together under the breeze of a ceiling fan',
#     'A man wearing a turquoise t-shirt eating with his daughter while his son does homework at the table',
#     'After a long ride through the countryside, a motorcycle rider arrives at a dirt parking lot with souvenir stands.'
#     ]
# # output:['There', 'is', 'a', 'man', 'cutting', 'an', 'apple', '.']

# # 分离整个句子
# words = nltk.word_tokenize(text)
# # 打标签
# words_tags = nltk.pos_tag(words) # 耗时长
# # output:[('There', 'EX'), ('is', 'VBZ'), ('a', 'DT'), ('man', 'NN'), ('cutting', 'VBG'), ('an', 'DT'), ('apple', 'NN'), ('.', '.')]

# # print(words_tags)
# words_list, tags_list = [], []
# # 标点符号也算
# n_longest = -1
# for sentence in sentences:
#     words = nltk.word_tokenize(sentence)
#     words_list.append(words)
#     # 打标签
#     words_tags = nltk.pos_tag(words) # 耗时长
#     # 便于实现，此处要加一
#     tags_list.append(words_tags)
#     if n_longest < len(words):
#          n_longest = len(words)

# print(words_list)
# print(tags_list)

# # 构建对应的字典序列列表
# b_pos_tags = np.zeros((len(tags_list), n_longest))
# for i, tag_list in enumerate(tags_list):
#     for j, (word, tag) in enumerate(tag_list):
#             if tag in pos_tags.keys():
#                 # word_idxs.append(self.vocab.stoi.get(word.lower(), 400000))
#                 # pos_tags.append(pos_tags[tag] + 1)
#                 # 1代表系动词或者实义动词；2代表代词或者名词；3代表连词
#                 b_pos_tags[i][j] = pos_tags[tag] + 1

# # 转为Tensor，并进行填充
# b_pos_tags = torch.tensor(b_pos_tags, dtype=torch.long)
# print(b_pos_tags)

# b_pos_tags  = rnn.pad_sequence(b_pos_tags, batch_first=True)

# batch_word_vectors = torch.ones((b_pos_tags.shape[0], b_pos_tags.shape[1], 10))

# zeros = b_pos_tags.new_zeros(b_pos_tags.shape)
# ones = b_pos_tags.new_ones(b_pos_tags.shape)
# entity_prob = torch.where(
#     torch.abs(b_pos_tags - 2) < 1e-10, zeros, ones)
# action_prob = torch.where(
#     torch.abs(b_pos_tags - 1) < 1e-10, zeros, ones)
# # 分离两种特征
# entity_features = batch_word_vectors * entity_prob.unsqueeze(2)
# action_feature = batch_word_vectors * action_prob.unsqueeze(2)

# print(entity_features.shape)
# print(action_feature.shape)