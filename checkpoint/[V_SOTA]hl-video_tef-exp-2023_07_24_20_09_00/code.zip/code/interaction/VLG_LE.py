import torch
from torch import nn
from torch.functional import F

class Syntac_GCN(nn.Module):
    def __init__(self, channel_in, channel_out, dropout=0.0, skip=False):
        super(Syntac_GCN, self).__init__()
        self.w_wc = nn.Sequential(
                    nn.Linear(channel_in*2, channel_out, bias=False),
                    nn.Dropout(dropout),
                    nn.ReLU(True),
                    nn.Linear(channel_out, 1, bias=False),
        )
        self.wd = nn.Sequential(
                    nn.Linear(channel_out, channel_out, bias=False),
                    nn.Dropout(dropout),
        )
        self.skip = skip

    def forward(self, input_):
        queries, wordlens, syntactic_dep = input_
        bs = queries.size(0)
        dim = queries.size(2)
        max_lens = queries.size(1)
        syntactic_dep = syntactic_dep[:,:max_lens,:max_lens]
        output = []
        for b in range(bs):
            b_edge = torch.nonzero(syntactic_dep[b, ...], as_tuple=False)
            i_idx = b_edge[:, 0] 
            j_idx = b_edge[:, 1]
            h_i = queries[b, i_idx, :]
            h_j = queries[b, j_idx, :]
            h = torch.cat((h_i, h_j), 1) # m * 512
            # print(h.shape)
            t = self.w_wc(h) 
            
            # equation 6
            T = torch.ones_like(syntactic_dep[0,...]).float()*(-100)
            T[i_idx, j_idx]=t.squeeze(-1)
            beta = F.softmax(T, dim=1)

            # equation 7
            H = torch.zeros(max_lens, max_lens, dim).type_as(queries)
            H[i_idx, j_idx, :] = self.wd(h_j)
            H = H * beta.unsqueeze(-1)
            H = H * (syntactic_dep[b, ...] > 0).unsqueeze(-1)
            b_output = F.relu(queries[b, ...] + torch.sum(H, dim=1)) 
            
            output.append(b_output)
        
        output = torch.stack(output, dim=0)
        if self.skip:
            assert dim == output.shape[2], 'Shape of queris is {}, Shape of output is {}'.format(dim, output.shape)
            output = output + queries
        return [output, wordlens, syntactic_dep]

class lstm_syntacGCN_encoder(nn.Module):
    # def __init__(self, cfg):
    def __init__(self, dim):
        super(lstm_syntacGCN_encoder, self).__init__()

        # Get relevant variables
        # hidden_size = cfg.MODEL.VLG.FEATPOOL.HIDDEN_SIZE
        # query_input_size = cfg.INPUT.PRE_QUERY_SIZE
        # query_hidden_size = cfg.MODEL.VLG.INTEGRATOR.QUERY_HIDDEN_SIZE
        
        # num_lstm_layers = cfg.MODEL.VLG.INTEGRATOR.LSTM.NUM_LAYERS  
        # bidirectional = cfg.MODEL.VLG.INTEGRATOR.LSTM.BIDIRECTIONAL
        # dropout_LSTM = cfg.MODEL.VLG.INTEGRATOR.LSTM.DROPOUT if num_lstm_layers > 1 else 0.0
        # dropout_Linear = cfg.MODEL.VLG.INTEGRATOR.DROPOUT_LINEAR
        # dropout_SGCN = cfg.MODEL.VLG.INTEGRATOR.DROPOUT_SGCN

        # num_layers = cfg.MODEL.VLG.INTEGRATOR.NUM_AGGREGATOR_LAYERS
        # assert num_layers > 0
        # skip_conn  = cfg.MODEL.VLG.INTEGRATOR.SKIP_CONN

        hidden_size = dim
        query_input_size = 512
        query_hidden_size = 512
        num_lstm_layers = 4  
        bidirectional = False
        dropout_LSTM = 0.0 if num_lstm_layers > 1 else 0.0
        dropout_Linear = 0.0
        dropout_SGCN = 0.0
        num_layers = 4
        assert num_layers > 0
        skip_conn  = True



        # Initialize LSTM
        if bidirectional:
            query_hidden_size //= 2
        self.lstm = nn.LSTM(query_input_size, query_hidden_size, 
                            num_layers=num_lstm_layers, batch_first=True, 
                            dropout=dropout_LSTM, bidirectional=bidirectional)

        # Initialize SyntacGCN
        layers = [Syntac_GCN(query_hidden_size, query_hidden_size, 
                                dropout_SGCN, skip=skip_conn)] * (num_layers)
        self.language_encoder = nn.Sequential(*layers)

        #Initialize linear mapping
        self.fc_query = nn.Sequential(
                    nn.Linear(query_hidden_size, hidden_size),
                    nn.Dropout(dropout_Linear),
                    nn.ReLU(True),
        )


    def forward(self, queries):
        # 随机初始化的参数
        batch_size, L_txt, D_txt = queries.shape
        # print('###############################'+str(querys_shape))
        # queries=torch.randn((2, 16, 300)).cuda()  # BS,Length,word_dim
        word_lens=torch.tensor([10, L_txt])
        syntactic_dep=torch.randint(0, 21, (batch_size, L_txt, L_txt)).cuda()
    
        # queries, wordlens, syntactic_dep = input_

        self.lstm.flatten_parameters()
        queries = self.lstm(queries)[0]

        queries = self.language_encoder([queries, word_lens, syntactic_dep])[0]

        # return self.fc_query(queries).transpose(1,2) # 隐藏为要放在最后
        return self.fc_query(queries)

