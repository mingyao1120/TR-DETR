import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class DecoderBlock(nn.Module):
    def __init__(self, d_model = 256, n_heads = 8, d_ffn = 2048):
        super().__init__()
        self.slot_attention = SlotAttention(d_model, n_heads)
        self.self_attention = nn.MultiheadAttention(d_model, n_heads)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ffn),
            nn.ReLU(),
            nn.Linear(d_ffn, d_model)
        )
        self.ln1 = nn.LayerNorm(d_model)
        self.ln2 = nn.LayerNorm(d_model)
        self.ln3 = nn.LayerNorm(d_model)

    def forward(self, z, q, h, z_mask=None, q_mask=None):
        # z: (N, L_v, D), q: (N, L_t, D), h: (N, L_t, D), z_mask: (N, L_v), q_mask: (N, L_t)
        # slot-attention
        delta_h = self.slot_attention(z, q + h, z_mask) # (N, L_t, D)
        h = self.ln1(h + delta_h) # (N, L_t, D)
        L_t = q.size(2)
        # self-attention
        h = h.transpose(0, 1) # (L_t, N, D)
        h2 = self.self_attention(h, h, h,
                                 key_padding_mask=q_mask,
                                 attn_mask=self._generate_square_subsequent_mask(L_t))[0] # (L_t, N ,D)
        h = self.ln2(h + h2) # (L_t ,N ,D)
        h = h.transpose(0 ,1) # (N ,L_t ,D)
        # feed-forward network
        h3 = self.ffn(h) # (N ,L_t ,D)
        h = self.ln3(h + h3) # (N ,L_t ,D)
        return h

    def _generate_square_subsequent_mask(self,size):
        mask = torch.triu(torch.ones(size,size), 1).bool()
        return mask

class SlotAttention(nn.Module):
    def __init__(self,d_model,n_heads):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        assert d_model % n_heads == 0
        self.d_head = d_model // n_heads
        self.w_z = nn.Linear(d_model,d_model)
        self.w_q = nn.Linear(d_model,d_model)
        self.w_v = nn.Linear(d_model,d_model)
        self.w_o = nn.Linear(d_model,d_model)

    def forward(self,z,q,z_mask=None):
        # z: (N,L_v,D), q: (N,L_t,D), z_mask: (N,L_v)
        N = z.size(0)
        L_v = z.size(1)
        L_t = q.size(1)

        z = self.w_z(z).view(N,L_v,self.n_heads,self.d_head).transpose(1 ,2) # (N,H,L_v,D_h)
        q = self.w_q(q).view(N,L_t,self.n_heads,self.d_head).transpose(1 ,2) # (N,H,L_t,D_h)

        m = torch.matmul(z,q.transpose(-1,-2)) / math.sqrt(self.d_head) # (N,H,L_v,L_t)

        if z_mask is not None:
            m.masked_fill_(z_mask.unsqueeze(1).unsqueeze(-1), float('-inf')) # (N,H,L_v,L_t)

        m = F.softmax(m,dim=-1) # (N,H,L_v,L_t)

        v = self.w_v(z).view(N,L_v,self.n_heads,self.d_head).transpose(1 ,2) # (N,H,L_v,D_h)

        delta_h = torch.matmul(m,v).transpose(1 ,2).contiguous().view(N,L_t,self.d_model) # (N,L_t,D)

        delta_h /= torch.sum(m,dim=-2).unsqueeze(-1) + 1e-9 # (N,L_t,D)

        delta_h = self.w_o(delta_h) # (N,L_t,D)

        return delta_h

src_vid = torch.ones((32, 75, 256))
src_txt = torch.ones((32, 32, 256))
src_vid_mask = torch.ones((32, 75))
src_txt_mask = torch.ones((32, 32))
h = src_vid
fuser = DecoderBlock()
print(fuser(src_txt, src_vid, h, src_txt_mask, src_vid_mask).shape)
