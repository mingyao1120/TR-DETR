import torch
import torch.nn as nn
import torch.nn.functional as F

class QueryEncoder(nn.Module):
    def __init__(self, in_channels = 256, out_channels = 256, kernel_sizes = [2 , 3]):
        super(QueryEncoder, self).__init__()
        # point-wise 1D convolution for unigram feature
        self.conv_u = nn.Conv1d(in_channels, out_channels, kernel_size=1)
        # temporal 1D convolution for bigram feature
        self.conv_b = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_sizes[0])
        # temporal 1D convolution for trigram feature
        self.conv_t = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_sizes[1])
        # global average pooling layer to obtain sentence-level feature
        self.pool = nn.AdaptiveAvgPool1d(1) # 用于提取sentence-level的语义
        # fully connected layer to integrate features
        self.linear = nn.Linear(out_channels * 3, out_channels)
        # store the kernel sizes as an attribute
        self.kernel_sizes = kernel_sizes

    def forward(self, x):
        # x is a sentence sequence of shape (batch_size, seq_len, in_channels)
        # transpose x to have shape (batch_size, in_channels, seq_len)
        x = torch.transpose(x, 1, 2)
        # apply convolution operations to obtain features
        q_u = self.conv_u(x) # unigram feature of shape (batch_size, out_channels, seq_len)
        q_b = self.conv_b(x) # bigram feature of shape (batch_size, out_channels, seq_len - kernel_sizes[0] + 1)
        q_t = self.conv_t(x) # trigram feature of shape (batch_size, out_channels, seq_len - kernel_sizes[1] + 1)
        q_g = self.pool(x)
        # print(q_u.shape, q_b.shape, q_t.shape, q_g.shape)
        # pad the features to have the same seq_len
        # q_b = F.pad(q_b, (self.kernel_sizes[0] - 1, 0))
        q_t = F.pad(q_t, (self.kernel_sizes[1] - 1, 0))
        q_b = torch.cat([q_b, q_g], dim = -1) # 将全局信息融入
        # concatenate the features along the channel dimension
        q_cat = torch.cat([q_u, q_b, q_t], dim=1) # shape (batch_size, out_channels * 3, seq_len)
        # apply linear layer to integrate features
        q_hat = self.linear(q_cat.permute(0, 2, 1)) # shape (batch_size, out_channels, seq_len)
        # transpose q_hat to have shape (batch_size, seq_len, out_channels)
        # q_hat = torch.transpose(q_hat, 1 ,2)
        return q_hat

# input_txt = torch.ones((32, 10, 256))
# model = QueryEncoder()
# print(model(input_txt).shape)