import torch
import torch.nn as nn
import torch.nn.functional as F
class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

class CustomLoss(nn.Module):
    def __init__(self, tau, in_dim, out_dim):
        super(CustomLoss, self).__init__()
        self.tau = tau
        self.MLP_v = MLP(in_dim, in_dim //2,  out_dim)
        self.MLP_t = MLP(in_dim, in_dim //2,  out_dim)

    def forward(self, v_f, t_w):
        B = v_f.shape[0]

        A = torch.matmul(v_f, t_w.transpose(1, 2))
        S_vt = 0.5 * (torch.sum(torch.max(A, dim=1).values) / B + torch.sum(torch.max(A, dim=0).values) / B)
        # loss = -0.5 * (F.log_softmax(S_vt / self.tau, dim=0).mean() + F.log_softmax(S_vt / self.tau, dim=1).mean())
        omega_v = F.softmax(self.MLP_v(v_f), dim=1)
        omega_t = F.softmax(self.MLP_t(t_w), dim=1)
        loss = -0.5 * (F.log_softmax(S_vt / self.tau, dim=0).mean() + F.log_softmax(S_vt / self.tau, dim=-1).mean()) + self.alpha * (omega_v * omega_t).sum()
        return loss

loss = CustomLoss(0.5, 512, 256)
vid = torch.ones((32, 75, 512))
# 转置文本
txt = torch.zeros((32, 32, 512))
# txt = txt.transpose(1, 2)
print(loss(vid, txt))
