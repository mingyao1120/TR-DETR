import torch
import torch.nn as nn
import torch.nn.functional as F

class LossFunction(nn.Module):
    def __init__(self, margin=0.1):
        super(LossFunction, self).__init__()
        self.margin = margin # a hyperparameter to control the margin between positive and negative samples

    def forward(self, src_vid, src_txt, pos_idx, neg_idx, src_vid_mask, src_txt_mask):
        batch_size, num_clips, seq_length = src_vid.size(0), src_vid.size(1), src_txt.size(1)
        # compute the cosine similarity between video and text features
        sim = F.cosine_similarity(src_vid.unsqueeze(2), src_txt.unsqueeze(1), dim=-1) # shape: (batch_size, num_clips, seq_length)

        # apply the masks to set the padding values to -inf
        src_vid_mask = ~src_vid_mask.bool()
        src_txt_mask = ~src_txt_mask.bool()
        sim = sim.masked_fill(src_vid_mask.unsqueeze(2), float("-inf"))
        sim = sim.masked_fill(src_txt_mask.unsqueeze(1), float("-inf"))

        # filter out the padded values
        mask_pos = pos_idx != -2
        pos_idx = torch.where(mask_pos, pos_idx, torch.zeros_like(pos_idx))
        mask_neg = neg_idx != -2
        neg_idx = torch.where(mask_neg, neg_idx, torch.zeros_like(neg_idx))

        # get the positive and negative similarity scores by indexing
        pos_sim = torch.gather(sim, 1, pos_idx.unsqueeze(-1).expand(-1, -1, sim.size(-1)).long()) # shape: (batch_size, num_clips, seq_length)
        neg_sim = torch.gather(sim, 1, neg_idx.unsqueeze(-1).expand(-1, -1, sim.size(-1)).long()) # shape: (batch_size, num_clips, seq_length)

        # apply the mask to set the padded values to -inf
        pos_sim = F.relu(pos_sim.masked_fill(~mask_pos.unsqueeze(-1), float("-inf")))
        neg_sim = F.relu(neg_sim.masked_fill(~mask_neg.unsqueeze(-1), float("-inf")))
        

        # compute the max-pooling over the sequence dimension
        pos_sim = torch.max(pos_sim, dim=-1)[0] # shape: (batch_size, num_clips)
        neg_sim = torch.max(neg_sim, dim=-1)[0] # shape: (batch_size, num_clips)
        # print(pos_sim.shape, neg_sim.shape)
        # compute the hinge loss with margin
        loss = F.relu(self.margin - pos_sim + neg_sim) # shape: (batch_size, num_clips)
        # print(loss[0])
        # compute the mean loss over the batch and clip dimensions
        # loss = torch.nanmean(loss)

        return loss.sum()
    
# from qd_detr.start_end_dataset import StartEndDataset,start_end_collate, prepare_batch_inputs
# # 先单独测试一下clip特征，读取对应的QV训练集
# dset_name = 'hl'
# data_path = 'data/highlight_train_release.jsonl'
# v_feat_dirs = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_features'
# q_feat_dir = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_text_features'
# train_set = StartEndDataset(dset_name, data_path, v_feat_dirs, q_feat_dir)

# # print(train_set[0]['model_inputs']['pos_idx'])

# from torch.utils.data import DataLoader
# train_loader = DataLoader(
#     train_set,
#     collate_fn=start_end_collate,
#     batch_size=32,
#     num_workers=4,
#     shuffle=True,
#     pin_memory=True
# )
# # next(iter(train_loader)得到的是一个元组，分别为model_input和target
# batch = next(iter(train_loader))
# model_inputs, targets = prepare_batch_inputs(batch[1], 'cpu', non_blocking=False)

# video_output, text_output, pos_idx, neg_idx = model_inputs['src_vid'], model_inputs['src_txt'], model_inputs['src_pos_idx'], model_inputs['src_neg_idx']
# src_txt_mask,   src_vid_mask = model_inputs['src_txt_mask'], model_inputs['src_vid_mask']
# # print(video_output, text_output, pos_idx, neg_idx)
# loss = LossFunction()
# print(loss(video_output, text_output,pos_idx, neg_idx, src_vid_mask,src_txt_mask ))