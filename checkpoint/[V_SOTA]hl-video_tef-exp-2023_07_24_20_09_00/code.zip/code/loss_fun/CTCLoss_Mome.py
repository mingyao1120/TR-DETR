import torch
import torch.nn as nn
import torch.nn.functional as F
from qd_detr.test_standardEncoder import SingleModalEncoder

class MomentumEncoder(nn.Module):
    def __init__(self, hidden_size=75, num_layers = 1,nhead=5):
        super(MomentumEncoder, self).__init__()
        # define a self-attention module
        self.self_attention = SingleModalEncoder(hidden_size, num_layers, nhead)
    
    def forward(self, sim_matrix):
        # sim_matrix: (b, n, t), similarity matrix between text tokens and video tokens
        b, n, t = sim_matrix.size()
        # reshape to (b * n, t)
        sim_matrix = sim_matrix.view(-1, t)
        # apply self-attention to generate soft labels
        soft_labels = self.self_attention(sim_matrix)
        # reshape back to (b, n ,t)
        soft_labels = soft_labels.view(b, n ,t)
        return soft_labels

class CTC_Loss(nn.Module):
    def __init__(self, temperature=0.07, momentum=0.999):
        super(CTC_Loss, self).__init__()
        self.temperature = temperature
        self.momentum = momentum
        # 定义一个动量编码器
        self.momentum_encoder = MomentumEncoder()


    def forward(self, vid_feat, txt_feat,  pos_idx, neg_idx, src_vid_mask=None, src_txt_mask=None):
        # sim_matrix: (b, n, t), similarity matrix between text tokens and video tokens
        # pos_idx: (b, t), positive indices for each video token
        # neg_idx: (b, t), negative indices for each video token
        # src_vid_mask: (b, t), mask for video tokens
        # src_txt_mask: (b, n), mask for text tokens
        sim_matrix = self.compute_sim_matrix(txt_feat, vid_feat) # (b, n ,t)

        # 动量处理；解决正负样本不均衡问题
        sim_matrix_mome = self.momentum_encoder(sim_matrix)

        b, n, t = sim_matrix.size()

        # mask out the padding tokens
        if src_vid_mask is not None:
            sim_matrix = sim_matrix.permute(0, 2, 1) * src_vid_mask.unsqueeze(1)# (b, t, n)
            sim_matrix_mome = sim_matrix_mome.permute(0, 2, 1) * src_vid_mask.unsqueeze(1)# (b, t, n)
        if src_txt_mask is not None:
            sim_matrix = sim_matrix * src_txt_mask.unsqueeze(2)
            sim_matrix_mome = sim_matrix_mome * src_txt_mask.unsqueeze(2)


        # TODO 压缩相似矩阵看看，将每个clip的相似度聚合（n个文本） ： sim_matrix(b, t, n) -> sim_matrix(b, t)
        sim_matrix = sim_matrix.sum(-1)
        sim_matrix_mome = sim_matrix_mome.sum(-1)
        pos_sim = torch.zeros((b, t))
        neg_sim = torch.zeros((b, t))
        pos_sim_mome = torch.zeros((b, t))
        neg_sim_mome = torch.zeros((b, t))
        # 使用for循环
        for b_i in range(b):
            for t_i in range(t):
                if pos_idx[b_i][t_i].long() != -2: # 这是clip_id，上面已经默认置零了
                    pos_sim[b_i][pos_idx[b_i][t_i].long()] = sim_matrix[b_i][pos_idx[b_i][t_i].long()]
                    pos_sim_mome[b_i][pos_idx[b_i][t_i].long()] = sim_matrix_mome[b_i][pos_idx[b_i][t_i].long()]
                # else:
                #     pos_sim[b_i][pos_idx[b_i][t_i].long()] = 0

                if neg_idx[b_i][t_i].long()  != -2:
                    neg_sim[b_i][neg_idx[b_i][t_i].long()] = sim_matrix[b_i][neg_idx[b_i][t_i].long()]
                    neg_sim_mome[b_i][neg_idx[b_i][t_i].long()] = sim_matrix_mome[b_i][neg_idx[b_i][t_i].long()]
                # else:
                #     neg_sim[b_i][neg_idx[b_i][t_i].long()] = 0

        # print(pos_sim, neg_sim)
        pos_exp = torch.exp(pos_sim / self.temperature) # (b, t)
        neg_exp = torch.exp(neg_sim / self.temperature) # (b, t)
        loss = -torch.log(pos_exp / (pos_exp + neg_exp)) # (b, t)
        loss = loss.mean() # scalar
        # 需要偏移一下
        print(pos_sim_mome, neg_sim_mome)
        pos_exp_mome = torch.exp((pos_sim_mome - pos_sim_mome.max())  / self.temperature) # (b, t)
        neg_exp_mome = torch.exp((neg_sim_mome - neg_sim_mome.max())/ self.temperature) # (b, t)
        loss_mome = -torch.log(pos_exp_mome / (pos_exp_mome + neg_exp_mome)) # (b, t)
        loss_mome = loss_mome.mean() # scalar
        print(pos_exp_mome, neg_exp_mome)
        return loss + loss_mome
    
    def compute_sim_matrix(self, txt_feat, vid_feat):
    # txt_feat: (b, n, d), text features
    # vid_feat: (b, t, d), video features

        b, n, d = txt_feat.size()
        t = vid_feat.size(1)

        # align the feature dimensions if needed
        # if self.align_dim:
        #     txt_feat = self.txt_linear(txt_feat) # (b, n, d)
        #     vid_feat = self.vid_linear(vid_feat) # (b, t, d)

        # normalize the features
        txt_feat = F.normalize(txt_feat, dim=-1) # (b, n, d)
        vid_feat = F.normalize(vid_feat, dim=-1) # (b, t, d)

        # compute the similarity matrix
        sim_matrix = torch.bmm(txt_feat, vid_feat.transpose(1, 2)) # (b, n ,t)

        return sim_matrix
    def update_momentum_encoder(self):
        # 更新动量编码器的参数，参考https://github.com/facebookresearch/moco/blob/master/moco/builder.py#L101-L105
        for param_q, param_k in zip(self.parameters(), self.momentum_encoder.parameters()):
            param_k.data = param_k.data * self.momentum + param_q.data * (1. - self.momentum)



# 测试一下dataloader

from qd_detr.start_end_dataset import StartEndDataset,start_end_collate, prepare_batch_inputs
# 先单独测试一下clip特征，读取对应的QV训练集
dset_name = 'hl'
data_path = 'data/highlight_train_release.jsonl'
v_feat_dirs = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_features'
q_feat_dir = '/home/4TDisk/zmy/datasets/MomentDETR_features/clip_text_features'
train_set = StartEndDataset(dset_name, data_path, v_feat_dirs, q_feat_dir)

# print(train_set[0]['model_inputs']['pos_idx'])

from torch.utils.data import DataLoader
train_loader = DataLoader(
    train_set,
    collate_fn=start_end_collate,
    batch_size=32,
    num_workers=4,
    shuffle=True,
    pin_memory=True
)
# next(iter(train_loader)得到的是一个元组，分别为model_input和target
batch = next(iter(train_loader))
model_inputs, targets = prepare_batch_inputs(batch[1], 'cpu', non_blocking=True)

video_output, text_output, pos_idx, neg_idx = model_inputs['src_vid'], model_inputs['src_txt'], model_inputs['src_pos_idx'], model_inputs['src_neg_idx']
src_txt_mask,   src_vid_mask = model_inputs['src_txt_mask'], model_inputs['src_vid_mask']
# print(video_output, text_output, pos_idx, neg_idx)
loss = CTC_Loss()
print(loss(video_output, text_output, pos_idx, neg_idx, src_txt_mask,   src_vid_mask))