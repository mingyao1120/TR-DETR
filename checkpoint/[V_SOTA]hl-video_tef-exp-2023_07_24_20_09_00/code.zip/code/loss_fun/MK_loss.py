import torch
import torch.nn as nn


class CMKTR_Loss(nn.Module):
    def __init__(self):
        super(CMKTR_Loss, self).__init__()

    def forward(self, vid_feat, txt_feat):
        # Compute the CMKTR loss
        vid_feat = vid_feat.mean(1)
        txt_feat = txt_feat.mean(1)
        cmktr_loss = torch.pow(vid_feat - txt_feat, 2).mean()  # Element-wise squared difference
        return cmktr_loss

class CMKTS_Loss(nn.Module):
    def __init__(self):
        super(CMKTS_Loss, self).__init__()

    def forward(self, Qv, Qt):
        # Compute the CMKTS loss
        cmkts_loss = torch.mean(Qv *   torch.log(  (Qv +  + 1e-4 )/ (Qt  + 1e-4 ))  )
        return cmkts_loss

# class CMKTS(nn.Module): # 计算Qv,Qt
#     def __init__(self, num_classes = 256, T = 0.07, in_features= 256): # 没有身份只能出此下策
#         super(CMKTS, self).__init__()
#         self.T = T
#         self.num_classes = num_classes
#         self.fc = nn.Linear(in_features, num_classes)  # in_features为输入特征维度

#     def compute_classification_probabilities(self, features):
#         logits = self.fc(features.cuda())
#         probabilities = torch.softmax(logits / self.T , dim=1).cuda()
#         return probabilities

#     def forward(self, src_vid, src_txt):
#         # Calculate Qv
#         Qv = self.compute_classification_probabilities(src_vid.cuda())

#         # Calculate Qt
#         Qt = self.compute_classification_probabilities(src_txt.cuda())

#         return Qv, Qt

class MK_Loss(nn.Module):
    def __init__(self):
        super(MK_Loss, self).__init__()
        self.cmktr_loss_fn = CMKTR_Loss()
        self.cmkts_loss_fn = CMKTS_Loss()
        # self.Q_CKT = CMKTS()

    def forward(self, vid_feat, txt_feat, src_vid_mask, src_txt_mask):
        # Compute the CMKTR loss
        cmktr_loss_val = self.cmktr_loss_fn(vid_feat, txt_feat) # ensor(0.1640, device='cuda:0', grad_fn=<MeanBackward0>) 

        Qv, Qt = vid_feat, txt_feat
        Qt_temp = torch.zeros_like(Qv).cuda()  + 1e-6 # 底数不能为0，否则无了
        Qt_temp[:,:Qt.size(1)] = Qt
        Qt = Qt_temp
        # print(Qt.shape)
        # Compute the CMKTS loss
        cmkts_loss_val = self.cmkts_loss_fn(Qv, Qt) 
        print(cmkts_loss_val) 
        # Compute the total loss
        total_loss = cmktr_loss_val + cmkts_loss_val
        # print(total_loss)
        return total_loss
    
# loss = MK_Loss()

# vid_feat = torch.zeros((32, 75, 256))
# txt_feat = torch.zeros((32, 32, 256))
# src_vid_mask = torch.ones((32, 75))
# src_txt_mask = torch.ones((32, 32))
# print(loss(vid_feat, txt_feat, src_vid_mask, src_txt_mask))