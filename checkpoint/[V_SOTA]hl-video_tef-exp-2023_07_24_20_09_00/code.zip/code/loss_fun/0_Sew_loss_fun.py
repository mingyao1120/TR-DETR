# 用于对齐模态，使用
# 导入PyTorch库
import torch
import torch.nn as nn
import torch.nn.functional as F
# 权重向量
class WeightVector(nn.Module):
    def __init__(self, dim):
        super(WeightVector, self).__init__()
        self.linear = nn.Linear(dim, 1) # 定义一个线性层

    def forward(self, x):
        return self.linear(x) # 返回线性层的输出

# 定义损失函数类
class MultimodalLoss(nn.Module):
    def __init__(self, alpha, m1, m2):
        super(MultimodalLoss, self).__init__()
        self.alpha = alpha # 相似度缩放因子
        self.m1 = m1 # 第一个边界
        self.m2 = m2 # 第二个边界
        self.WeightVector = WeightVector(512)

    def forward(self, v, t, y):
        # 计算图像和文本之间的余弦相似度
        cos_sim = F.cosine_similarity(v.unsqueeze(2), t.unsqueeze(1), dim=-1)
        # 计算图像和文本之间的加权点积相似度
        w = self.WeightVector(t)
        dot_sim = torch.einsum('bij,bj->bi', v.unsqueeze(2) * w.unsqueeze(1), t)
        # 计算三元组损失函数的两个部分
        pull_loss = torch.log(1 + torch.sum(torch.exp(self.alpha * (cos_sim - cos_sim[torch.arange(v.size(0)), y] + self.m1)), dim=-1))
        push_loss = torch.log(1 + torch.sum(torch.exp(self.alpha * (cos_sim - cos_sim[torch.arange(v.size(0)), y] + self.m2)), dim=-1))
        # 计算三元组损失函数的总和
        triplet_loss = pull_loss + push_loss
        # 计算多分类损失函数
        multiclass_loss = F.cross_entropy(dot_sim, y)
        # 计算总的损失函数
        total_loss = triplet_loss + multiclass_loss
        # 返回总的损失函数
        return total_loss

# 实例化损失函数类
loss_fn = MultimodalLoss(alpha=0.2, m1=0.5, m2=0.7)
# 假设你已经有了图像的特征向量v，文本的特征向量t，匹配标签y，以及权重向量w
# 你可以用以下的代码来计算损失函数的值
v = torch.ones((32, 75, 512))
t = torch.ones((32, 32, 512))
# 一一对应
y = [idx for idx,token in enumerate(v)]
loss = loss_fn(v, t, y)