import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# VCTC
class CTC_Loss(nn.Module):
    def __init__(self, temperature=0.07):
        super(CTC_Loss, self).__init__()
        self.temperature = temperature

    def forward(self, vid_feat, txt_feat, pos_mask, src_vid_mask=None, src_txt_mask=None):
        # vid_feat: (bs, t, d)
        # txt_feat: (bs, n, d)
        # pos_mask: (bs, t)
        # src_vid_mask: (bs, t) or None
        # src_txt_mask: (bs, n) or None
        bs = vid_feat.size(0)
        t = vid_feat.size(1)
        n = txt_feat.size(1)
        d = vid_feat.size(2)
        # normalize the feature vectors
        vid_feat = F.normalize(vid_feat, dim=2) # (bs, t, d)
        txt_feat = F.normalize(txt_feat, dim=2) # (bs, n, d)
        # compute the global text feature by mean pooling
        if src_txt_mask is not None:
            src_txt_mask = src_txt_mask.unsqueeze(-1) # (bs, n, 1)
            txt_feat = txt_feat * src_txt_mask # (bs, n, d)
            txt_global = torch.sum(txt_feat, dim=1) / torch.sum(src_txt_mask, dim=1) # (bs, d)
        else:
            txt_global = torch.mean(txt_feat, dim=1) # (bs, d)
        # compute the similarity matrix
        sim_mat = torch.bmm(vid_feat, txt_global.unsqueeze(-1)).squeeze(-1) # (bs, t)
        # apply the video mask if given
        if src_vid_mask is not None:
            sim_mat = sim_mat * src_vid_mask # (bs, t)
        # compute the logits and labels
        logits = sim_mat / self.temperature # (bs, t)
        labels = pos_mask.long() # (bs, t)
        # compute the binary cross entropy loss with logits
        loss = F.binary_cross_entropy_with_logits(logits, labels.float()) # scalar
        # return the loss
        return loss

# AlignmentCTC
# class CTC_Loss(nn.Module):
#     def __init__(self, margin=0.1):
#         super(CTC_Loss, self).__init__()
#         self.margin = margin
#         self.margin_ranking_loss = nn.MarginRankingLoss(margin=self.margin)


#     # def forward(self, vid_feat, txt_feat,  pos_idx, neg_idx, src_vid_mask=None, src_txt_mask=None):
#     def forward(self, vid_feat, txt_feat,  pos_mask, src_vid_mask=None, src_txt_mask=None):
#         sim_matrix = self.compute_sim_matrix(txt_feat, vid_feat) # (b, n ,t)
#         b, n, t = sim_matrix.size()

#         # mask out the padding tokens
#         if src_vid_mask is not None:
#             sim_matrix = sim_matrix.permute(0, 2, 1) * src_vid_mask.unsqueeze(2)# (b, t, n)
#         if src_txt_mask is not None:
#             sim_matrix = sim_matrix * src_txt_mask.unsqueeze(1)
        
#         # 向量化
#         # print(pos_mask.shape) # torch.Size([32, 75])
#         pos_sim = sim_matrix * pos_mask.unsqueeze(-1).bool()
#         neg_sim = sim_matrix * (~pos_mask.unsqueeze(-1).bool())
#         # print(pos_sim.shape, neg_sim.shape)
#         # print(pos_mask, (~pos_mask.bool()))
#         pos_sim = pos_sim.contiguous().view(-1) # (b * t)
#         neg_sim = neg_sim.contiguous().view(-1) # (b * t)
        

#         # compute the contrastive loss
#         loss = self.margin_ranking_loss(pos_sim, neg_sim, torch.ones(b * t * n).to(pos_sim.device)) # scalar
#         return loss
    
#     def compute_sim_matrix(self, txt_feat, vid_feat):
#         b, n, d = txt_feat.size()
#         t = vid_feat.size(1)
#         # normalize the features
#         txt_feat = F.normalize(txt_feat, dim=-1) # (b, n, d)
#         vid_feat = F.normalize(vid_feat, dim=-1) # (b, t, d)
#         # compute the similarity matrix
#         sim_matrix = torch.bmm(txt_feat, vid_feat.transpose(1, 2)) # (b, n ,t)
#         return sim_matrix


# class CTC_Loss(nn.Module):
#     def __init__(self, temperature=0.07):
#         super(CTC_Loss, self).__init__()
#         self.temperature = temperature


#     def forward(self, vid_feat, txt_feat,  pos_mask, src_vid_mask=None, src_txt_mask=None):
#         sim_matrix = self.compute_sim_matrix(txt_feat, vid_feat) # (b, n ,t)
#         b, n, t = sim_matrix.size()

#         # mask out the padding tokens
#         if src_vid_mask is not None:
#             sim_matrix = sim_matrix.permute(0, 2, 1) * src_vid_mask.unsqueeze(2)# (b, t, n)
#         if src_txt_mask is not None:
#             sim_matrix = sim_matrix * src_txt_mask.unsqueeze(1)
        
#         sim_matrix = sim_matrix.mean(-1)
        
#         # 向量化
#         # print(pos_mask.shape) # torch.Size([32, 75])
#         pos_sim = sim_matrix * pos_mask.bool()
#         neg_sim = sim_matrix * (~pos_mask.bool())

#         # print(pos_mask, (~pos_mask.bool()))
#         pos_exp = torch.exp(pos_sim / self.temperature)+1e-6 # (b, t)
#         neg_exp = torch.exp(neg_sim / self.temperature)+1e-6 # (b, t)
#         loss = -torch.log(pos_exp / (pos_exp + neg_exp)) # (b, t)

#         loss = loss.mean() # scalar
#         return loss
    
#     def compute_sim_matrix(self, txt_feat, vid_feat):
#         b, n, d = txt_feat.size()
#         t = vid_feat.size(1)
#         # normalize the features
#         txt_feat = F.normalize(txt_feat, dim=-1) # (b, n, d)
#         vid_feat = F.normalize(vid_feat, dim=-1) # (b, t, d)
#         # compute the similarity matrix
#         sim_matrix = torch.bmm(txt_feat, vid_feat.transpose(1, 2)) # (b, n ,t)
#         return sim_matrix

# tensor([0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,                     | 7/226 [00:01<00:34,  6.29it/s]
#         0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 1., 1., 1., 1., 1., 1.,
#         1., 1., 1., 1., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
#         0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
#         0., 0., 0.], device='cuda:0') tensor([ True,  True,  True,  True,  True,  True,  True,  True,  True,  True,
#          True,  True,  True,  True,  True,  True,  True,  True,  True,  True,
#          True,  True,  True,  True,  True,  True,  True,  True,  True,  True,
#         False, False, False, False, False, False, False, False, False, False,
#          True,  True,  True,  True,  True,  True,  True,  True,  True,  True,
#          True,  True,  True,  True,  True,  True,  True,  True,  True,  True,
#          True,  True,  True,  True,  True,  True,  True,  True,  True,  True,
#          True,  True,  True,  True,  True], device='cuda:0')