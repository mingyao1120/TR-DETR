import torch
import torch.nn as nn

# 定义一个单模态编码器层
class SingleModalEncoderLayer(nn.TransformerEncoderLayer):
    def __init__(self, d_model, nhead):
        super().__init__(d_model, nhead)
        self.self_attn = nn.MultiheadAttention(d_model, nhead) # 使用多头自注意力

    def forward(self, src, src_mask=None, src_key_padding_mask=None):
        # src: (src_len, batch_size, d_model)
        # src_mask: (src_len, src_len)
        # src_key_padding_mask: (batch_size, src_len)
        src = src.permute(1, 0, 2)
        src2 = self.self_attn(src, src, src, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0] # (src_len, batch_size, d_model)
        src = src + self.dropout1(src2) 
        src = self.norm1(src)
        src2 = self.linear2(self.dropout(self.activation(self.linear1(src))))
        src = src + self.dropout2(src2)
        src = self.norm2(src)
        return src

# 定义一个单模态编码器
class SingleModalEncoder(nn.TransformerEncoder):
    def __init__(self, d_model= 256, num_layers = 3, nhead=8):
        encoder_layer = SingleModalEncoderLayer(d_model=d_model, nhead=nhead) # 创建一个单模态编码器层
        super().__init__(encoder_layer, num_layers) # 初始化父类的属性
    
# 创建一个单模态编码器
# single_modal_encoder = SingleModalEncoder(256)

# # 创建一些输入
# src = torch.randn(32, 10, 256) # (batch_size, src_len, d_model)

# # 转置输入，使其符合编码器的要求
# src = src.transpose(0, 1) # (src_len, batch_size, d_model)

# # 使用单模态编码器对输入进行编码
# output = single_modal_encoder(src) # (src_len, batch_size, d_model)

# # 转置输出，使其符合你的要求
# output = output.transpose(0, 1) # (batch_size, src_len, d_model)
# print(output.shape)

# 你的输入数据和网络定义都是正确的，但是你没有调用网络的forward方法，所以没有得到输出。你需要在创建网络后，对输入数据进行转置，然后调用网络的forward方法，例如：

# ```python
# # 创建一个单模态编码器
# single_modal_encoder = SingleModalEncoder(d_model=256, num_layers=3)

# # 创建一些输入
# src = torch.randn(32, 10, 256) # (batch_size, src_len, d_model)

# # 转置输入，使其符合编码器的要求
# src = src.transpose(0, 1) # (src_len, batch_size, d_model)

# # 使用单模态编码器对输入进行编码
# output = single_modal_encoder(src) # (src_len, batch_size, d_model)
# ```

# 总体的参数量为多少？这个问题可以通过计算每一层的参数量，然后相加得到。每一层的参数量主要由三部分组成：自注意力层，前馈神经网络层，和层归一化层。自注意力层的参数量为：

# $$
# 4 \times d_{model} \times d_{model} + 4 \times d_{model} \times n_{head}
# $$

# 前馈神经网络层的参数量为：

# $$
# 2 \times d_{model} \times d_{ff} + 2 \times d_{ff}
# $$

# 其中$d_{ff}$是前馈神经网络层的隐藏维度，默认为$d_{model} \times 4$。层归一化层的参数量为：

# $$
# 2 \times d_{model}
# $$

# 所以每一层的总参数量为：

# $$
# 4 \times d_{model} \times d_{model} + 4 \times d_{model} \times n_{head} + 2 \times d_{model} \times d_{ff} + 2 \times d_{ff} + 2 \times d_{model}
# $$

# 如果$d_{model}=256$，$n_{head}=8$，$d_{ff}=1024$，那么每一层的总参数量为：

# $$
# 1040384
# $$

# 如果有3层，那么总体的参数量为：

# $$
# 3121152
# $$