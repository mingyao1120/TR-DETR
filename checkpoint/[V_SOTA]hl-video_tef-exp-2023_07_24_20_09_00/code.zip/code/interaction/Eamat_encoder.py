import torch
import torch.nn as nn

# from .operation import Conv1D

import torch.nn.functional as F
import numpy as np
import math

def mask_logits(inputs, mask, mask_value=-1e30):
    mask = mask.type(torch.float32)
    return inputs + (1.0 - mask) * mask_value


class Conv1D(nn.Module):
    def __init__(self,
                 in_dim,
                 out_dim,
                 kernel_size=1,
                 stride=1,
                 padding=0,
                 bias=True):
        super(Conv1D, self).__init__()
        self.conv1d = nn.Conv1d(in_channels=in_dim,
                                out_channels=out_dim,
                                kernel_size=kernel_size,
                                padding=padding,
                                stride=stride,
                                bias=bias)

    def forward(self, x):
        # suppose all the input with shape (batch_size, seq_len, dim)
        x = x.transpose(1, 2)  # (batch_size, dim, seq_len)
        x = self.conv1d(x)
        return x.transpose(1, 2)  # (batch_size, seq_len, dim)

# 这段代码根本没用
class LSTMEncoder(nn.Module):
    def __init__(self,
                 in_dim,
                 out_dim,
                 num_layers,
                 bi_direction=False,
                 drop_rate=0.0):
        super(LSTMEncoder, self).__init__()

        self.layers_norm1 = nn.LayerNorm(in_dim, eps=1e-6)
        self.layers_norm2 = nn.LayerNorm(out_dim, eps=1e-6)

        self.dropout = nn.Dropout(p=drop_rate)
        self.encoder = nn.LSTM(in_dim,
                               out_dim // 2 if bi_direction else out_dim,
                               num_layers=num_layers,
                               bidirectional=bi_direction,
                               dropout=drop_rate,
                               batch_first=True)

        self.linear = Conv1D(in_dim=out_dim,
                             out_dim=out_dim,
                             kernel_size=1,
                             stride=1,
                             bias=True,
                             padding=0)

    def forward(self, input_feature):
        input_feature = self.layers_norm1(input_feature)
        output, _ = self.encoder(input_feature)
        output = self.layers_norm2(output)
        output = self.dropout(output)
        output = self.linear(output)
        return output


class MultiStepLSTMEncoder(nn.Module):
    def __init__(self,
                 in_dim,
                 out_dim,
                 num_layers,
                 num_step=1,
                 bi_direction=False,
                 drop_rate=0.0):
        super(MultiStepLSTMEncoder, self).__init__()

        self.num_step = num_step
        self.out_dim = out_dim
        self.layers_norm = nn.LayerNorm(in_dim, eps=1e-6)

        self.dropout = nn.Dropout(p=drop_rate)
        # 这里将LSTM改为GRU
        # self.encoder = nn.ModuleList([
        #     nn.LSTM(in_dim,
        #             out_dim // 2 if bi_direction else out_dim,
        #             num_layers=num_layers,
        #             bidirectional=bi_direction,
        #             dropout=drop_rate,
        #             batch_first=True) for _ in range(num_step)
        # ])
        self.encoder = nn.ModuleList([
            nn.Linear(in_dim, out_dim) for _ in range(num_step)
        ])


        self.linear = Conv1D(in_dim=int(num_step * out_dim),
                             out_dim=out_dim,
                             kernel_size=1,
                             stride=1,
                             bias=True,
                             padding=0)

    def forward(self, input_feature):
        input_feature = self.layers_norm(input_feature)
        B, seq_len, _ = input_feature.shape
        # assert seq_len // self.num_step == 0, "length of sequence({}) must be devided by num_step({})".format(
        #     seq_len, self.num_step)
        output = []
        for i in range(self.num_step):
            encoder_i = self.encoder[i]
            output_i = input_feature.new_zeros([B, seq_len, self.out_dim])
            input_i_len = (seq_len // (i + 1)) * (i + 1)
            for j in range(i + 1):
                input_j = input_feature[:, j:input_i_len:(i + 1), :]
                # output_j, _ = encoder_i(input_j)
                output_j = encoder_i(input_j)
                output_i[:, j:input_i_len:(i + 1), :] = output_j
            output_i = self.dropout(output_i)
            output.append(output_i)
        output = torch.cat(output, dim=2)
        output = self.linear(output)
        return output

class TemporalContextModule(nn.Module):
    def __init__(self, in_dim, out_dim, kernels=[3], drop_rate=0.):
        super(TemporalContextModule, self).__init__()
        self.dropout = nn.Dropout(p=drop_rate)
        self.temporal_convs = nn.ModuleList([
            Conv1D(in_dim=in_dim,
                   out_dim=out_dim,
                   kernel_size=s,
                   stride=1,
                   padding=s // 2,
                   bias=True) for s in kernels
        ])
        self.out_layer = Conv1D(in_dim=out_dim * len(kernels),
                                out_dim=out_dim,
                                kernel_size=1,
                                stride=1,
                                padding=0,
                                bias=True)

    def forward(self, input_feature):
        intermediate = []
        for layer in self.temporal_convs:
            intermediate.append(layer(input_feature))
        intermediate = torch.cat(intermediate, dim=-1)
        out = self.out_layer(intermediate)
        return out

class MultiLSTMAttention(nn.Module):
    # def __init__(self, configs):
    def __init__(self, dim, num_heads, drop_rate, num_layers, num_step, bi_direction):
        super(MultiLSTMAttention, self).__init__()
        # dim = configs.dim
        # num_heads = configs.num_heads
        # drop_rate = configs.drop_rate
        # num_layers = configs.num_layers
        # num_step = configs.num_step
        # bi_direction = configs.bi_direction
        dim = dim
        num_heads = num_heads
        drop_rate = drop_rate
        num_layers = num_layers
        num_step = num_step
        bi_direction = bi_direction

        assert dim % num_heads == 0, 'The channels (%d) is not a multiple of attention heads (%d)' % (
            dim, num_heads)
        self.head_size, self.num_heads, self.dim = int(
            dim / num_heads), num_heads, dim
        self.dropout = nn.Dropout(p=drop_rate)
        self.query = MultiStepLSTMEncoder(in_dim=dim,
                                          out_dim=dim,
                                          num_layers=num_layers,
                                          num_step=num_step,
                                          bi_direction=bi_direction,
                                          drop_rate=drop_rate)
        self.key = MultiStepLSTMEncoder(in_dim=dim,
                                        out_dim=dim,
                                        num_layers=num_layers,
                                        num_step=num_step,
                                        bi_direction=bi_direction,
                                        drop_rate=drop_rate)
        self.value = MultiStepLSTMEncoder(in_dim=dim,
                                          out_dim=dim,
                                          num_layers=num_layers,
                                          num_step=num_step,
                                          bi_direction=bi_direction,
                                          drop_rate=drop_rate)
        # 暂时换为线性层看看，记得注释掉模型中的其他架构
        # self.query = F.linear(in_dim=dim,out_dim=dim, num_layers=num_layers,drop_rate=drop_rate)
        # self.key = F.linear(in_dim=dim,out_dim=dim, num_layers=num_layers,drop_rate=drop_rate)
        # self.value = F.linear(in_dim=dim,out_dim=dim, num_layers=num_layers,drop_rate=drop_rate)

      
        self.layer_norm1 = nn.LayerNorm(dim, eps=1e-6)
        self.layer_norm2 = nn.LayerNorm(dim, eps=1e-6)
        self.out_layer1 = Conv1D(in_dim=dim,
                                 out_dim=dim,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0,
                                 bias=True)
        self.output_activation = nn.GELU()
        self.out_layer2 = Conv1D(in_dim=dim,
                                 out_dim=dim,
                                 kernel_size=1,
                                 stride=1,
                                 padding=0,
                                 bias=True)

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_heads, self.head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1,
                         3)  

    @staticmethod
    def combine_last_two_dim(x):
        old_shape = list(x.size())
        new_shape = old_shape[:-2] + [old_shape[-2] * old_shape[-1]]
        return x.reshape(shape=new_shape)
    
    def forward(self, x, mask=None):
        output = self.layer_norm1(x)  
        query = self.transpose_for_scores(
            self.query(output)) 
        key = self.transpose_for_scores(self.key(output))
        value = self.transpose_for_scores(self.value(output))
        attention_scores = torch.matmul(query, key.transpose(
            -1, -2))  
        attention_scores = attention_scores / math.sqrt(self.head_size)
        if mask is not None:  
            mask = mask.unsqueeze(1).unsqueeze(
                2) 
            attention_scores = mask_logits(attention_scores, mask)
        attention_probs = torch.softmax(
            attention_scores,
            dim=-1) 
        attention_probs = self.dropout(attention_probs)
        value = torch.matmul(
            attention_probs,
            value) 
        value = self.combine_last_two_dim(value.permute(
            0, 2, 1, 3))  
        output = self.dropout(value)
        residual = x + output
        output = self.layer_norm2(residual)
        output = self.out_layer1(output)
        output = self.output_activation(output)
        output = self.dropout(output)
        output = self.out_layer2(output) + residual
        return output