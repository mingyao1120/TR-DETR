import torch
import torch.nn as nn
import torch.nn.functional as F

# 定义一个三元组损失函数类
class TripletLoss(nn.Module):
    # 初始化函数，接收一个超参数margin
    def __init__(self, margin=1.0):
        super(TripletLoss, self).__init__()
        self.margin = margin
    
    # 前向传播函数，接收锚点、正样本、负样本的联合表征矩阵
    def forward(self, src_vid_anchor, src_vid_pos, src_vid_neg):
        # 计算锚点和正样本之间的欧几里得距离
        dist_pos = F.pairwise_distance(src_vid_anchor, src_vid_pos, p=2)

        # 计算锚点和负样本之间的欧几里得距离
        dist_neg = F.pairwise_distance(src_vid_anchor, src_vid_neg, p=2)

        # 计算三元组损失
        triplet_loss = F.relu(dist_pos - dist_neg + self.margin)

        # 对batch_size维度求平均
        triplet_loss = torch.mean(triplet_loss)

        return triplet_loss
